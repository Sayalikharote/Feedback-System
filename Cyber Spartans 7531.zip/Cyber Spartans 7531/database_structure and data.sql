CREATE DATABASE  IF NOT EXISTS `mhrdfeedbacksystem` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `mhrdfeedbacksystem`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: mhrdfeedbacksystem
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_login_details`
--

DROP TABLE IF EXISTS `admin_login_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_login_details` (
  `user_id` varchar(45) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  `role` varchar(30) NOT NULL,
  `state` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `name` varchar(70) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_login_details`
--

LOCK TABLES `admin_login_details` WRITE;
/*!40000 ALTER TABLE `admin_login_details` DISABLE KEYS */;
INSERT INTO `admin_login_details` VALUES ('admin','new','hrd','Maharashtra','admin@gmail.com','9890054786','admin_name'),('admin1','world','state','Maharashtra','admin1@gmail.com','8446915866','admin1_name'),('admin2','world','state','Maharashtra','admin2@gmail.com','9028434194','admin2_name'),('Sayali','aaa','hrd','Maharashtra','Sayali@gamil.com','9156644798','Sayali');
/*!40000 ALTER TABLE `admin_login_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_details`
--

DROP TABLE IF EXISTS `feedback_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_details` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(100) NOT NULL,
  `feedback` varchar(45) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `qid` varchar(10) DEFAULT NULL,
  `school_code` varchar(45) DEFAULT NULL,
  `class` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_details`
--

LOCK TABLES `feedback_details` WRITE;
/*!40000 ALTER TABLE `feedback_details` DISABLE KEYS */;
INSERT INTO `feedback_details` VALUES (1,'How was the help you received after specifying your problem?            ','Poor','MATH','1','1001','6'),(2,'How was the communication skills of the teacher?            ','Average','MATH','2','1001','6'),(3,'how was the use of teaching aids during class ?           ','Good','MATH','3','1001','6'),(4,'How was the behavior of the teacher in the class?   ','Very Good','MATH','4','1001','6'),(5,'How was the Revisions taken by the teacher?','Excellent','MATH','5','1001','6'),(6,'How was the help you received after specifying your problem?            ','Very Good','MATH','1','1001','6'),(7,'How was the communication skills of the teacher?            ','Good','MATH','2','1001','6'),(8,'how was the use of teaching aids during class ?           ','Good','MATH','3','1001','6'),(9,'How was the behavior of the teacher in the class?   ','Good','MATH','6','1001','6'),(10,'How was the help you received after specifying your problem?            ','Average','MATH','1','1001','6'),(11,'How was the communication skills of the teacher?            ','Average','MATH','2','1001','6'),(12,'how was the use of teaching aids during class ?           ','Average','MATH','3','1001','6'),(13,'How was the behavior of the teacher in the class?   ','Average','MATH','6','1001','6'),(14,'How was the help you received after specifying your problem?            ','Poor','MATH','1','1001','6'),(15,'How was the communication skills of the teacher?            ','Average','MATH','2','1001','6'),(16,'how was the use of teaching aids during class ?           ','Good','MATH','3','1001','6'),(17,'How was the behavior of the teacher in the class?   ','Very Good','MATH','6','1001','6'),(18,'How was the help you received after specifying your problem?            ','Average','MATH','1','1001','6'),(19,'How was the communication skills of the teacher?            ','Very Good','MATH','2','1001','6'),(20,'how was the use of teaching aids during class ?           ','Good','MATH','3','1001','6'),(21,'How was the behavior of the teacher in the class?   ','Excellent','MATH','6','1001','6'),(22,'How was the help you received after specifying your problem?            ',NULL,'MATH','1','1001','6'),(23,'How was the communication skills of the teacher?            ',NULL,'MATH','2','1001','6'),(24,'how was the use of teaching aids during class ?           ',NULL,'MATH','3','1001','6'),(25,'How was the behavior of the teacher in the class?   ',NULL,'MATH','6','1001','6'),(26,'How was the help you received after specifying your problem?            ','Average','MATH','1','1001','6'),(27,'How was the communication skills of the teacher?            ','Good','MATH','2','1001','6'),(28,'how was the use of teaching aids during class ?           ','Very Good','MATH','3','1001','6'),(29,'How was the behavior of the teacher in the class?   ','Excellent','MATH','6','1001','6'),(30,'How was the help you received after specifying your problem?            ','Poor','MATH','1','1001','6'),(31,'How was the communication skills of the teacher?            ','Average','MATH','2','1001','6'),(32,'how was the use of teaching aids during class ?           ','Good','MATH','3','1001','6'),(33,'How was the behavior of the teacher in the class?   ','Very Good','MATH','6','1001','6'),(34,'How was the help you received after specifying your problem?            ','Poor','MATH','1','1001','6'),(35,'How was the communication skills of the teacher?            ','Average','MATH','2','1001','6'),(36,'how was the use of teaching aids during class ?           ','Good','MATH','3','1001','6'),(37,'How was the behavior of the teacher in the class?   ','Excellent','MATH','6','1001','6'),(38,'How was the help you received after specifying your problem?            ','Good','MATH','1','1001','6'),(39,'How was the communication skills of the teacher?            ','Good','MATH','2','1001','6'),(40,'how was the use of teaching aids during class ?           ','Very Good','MATH','3','1001','6'),(41,'How was the behavior of the teacher in the class?   ','Very Good','MATH','6','1001','6');
/*!40000 ALTER TABLE `feedback_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_details`
--

DROP TABLE IF EXISTS `question_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_details` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(100) NOT NULL,
  `op1` varchar(15) DEFAULT NULL,
  `op2` varchar(15) DEFAULT NULL,
  `op3` varchar(15) DEFAULT NULL,
  `op4` varchar(15) DEFAULT NULL,
  `op5` varchar(15) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `class` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_details`
--

LOCK TABLES `question_details` WRITE;
/*!40000 ALTER TABLE `question_details` DISABLE KEYS */;
INSERT INTO `question_details` VALUES (2,'How was the communication skills of the teacher?            ','Poor','Average','Good','Very Good','Excellent','MATH','6'),(3,'how was the use of teaching aids during class ?           ','Poor','Average','Good','Very Good','Excellent','MATH','6'),(6,'How was the behavior of the teacher in the class?   ','Poor','Average','Good','Very Good','Excellent','MATH','6');
/*!40000 ALTER TABLE `question_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_login_details`
--

DROP TABLE IF EXISTS `school_login_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_login_details` (
  `school_code` varchar(45) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  `status` varchar(11) NOT NULL,
  PRIMARY KEY (`school_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_login_details`
--

LOCK TABLES `school_login_details` WRITE;
/*!40000 ALTER TABLE `school_login_details` DISABLE KEYS */;
INSERT INTO `school_login_details` VALUES ('1001','hello','unapproved');
/*!40000 ALTER TABLE `school_login_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_details`
--

DROP TABLE IF EXISTS `student_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_details` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `class` varchar(10) DEFAULT NULL,
  `school_code` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_details`
--

LOCK TABLES `student_details` WRITE;
/*!40000 ALTER TABLE `student_details` DISABLE KEYS */;
INSERT INTO `student_details` VALUES (1,'mj','6','null'),(3,'','6','null'),(4,'ss','6','null'),(5,'dsd','8','null'),(6,'sss','6','null'),(7,'xxx','6','null'),(8,'','6','null'),(9,'df','6','null'),(10,'asa','6','null'),(11,'sasa','6','null'),(12,'sasa','7','null'),(13,'sahil','6','null'),(14,'sahil','6','null'),(15,'mayuresh','10th','1001'),(16,'mj','6th','null'),(17,'mj','6','1001'),(18,'mj','6','1001'),(19,'sahil','6','1001'),(20,'sahil','6','1001'),(21,'sahil','6','1001'),(22,'sdsdsdsds','6','1001'),(23,'sahil','6','1001'),(24,'dsd','6','1001'),(25,'mayuresh','6','1001'),(26,'kh','6','1001'),(27,'Kaivalya Banot','6','1001'),(28,'mayuresh','6','1001'),(29,'sayali','6','1001'),(30,'Sahil Saraf','6','1001'),(31,'mayuresh','6','1001'),(32,'mayuresh','6','1001');
/*!40000 ALTER TABLE `student_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suggestion_details`
--

DROP TABLE IF EXISTS `suggestion_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suggestion_details` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `suggestion` varchar(200) DEFAULT NULL,
  `class` varchar(2) DEFAULT NULL,
  `school_code` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suggestion_details`
--

LOCK TABLES `suggestion_details` WRITE;
/*!40000 ALTER TABLE `suggestion_details` DISABLE KEYS */;
INSERT INTO `suggestion_details` VALUES (2,'More use of teaching aids should be done by the teachers              \r\n            ','6','1001'),(3,'The home works must be Checked regularly so that the\r\nstudent performance will be known to teachers..       ','6','1001'),(4,'Teachers must communicate well with all the students in their class..        ','6','1001'),(5,'Teachers must complete their subject Syllabus on time..    ','6','1001'),(6,'               \r\n                    None',NULL,NULL),(7,'               \r\n need of improghhgjmmghnjm                   ',NULL,NULL);
/*!40000 ALTER TABLE `suggestion_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-02 17:13:26
